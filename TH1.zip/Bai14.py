n = int(input("Nhập số bí mật: "))
while n < 11:
    if n > 5:
        print("Số bí mật là số bé hơn.")
    elif n < 5:
        print("Số bí mật là số lớn hơn.")
    else:
        break
        print("Bạn đã đoán đúng.")